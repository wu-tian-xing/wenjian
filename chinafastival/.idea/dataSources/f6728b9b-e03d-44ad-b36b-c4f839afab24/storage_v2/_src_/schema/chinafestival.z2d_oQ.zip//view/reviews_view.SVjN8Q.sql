create definer = root@localhost view reviews_view as
select `chinafestival`.`users`.`u_name`      AS `u_name`,
       `chinafestival`.`users`.`headphoto`   AS `headphoto`,
       `chinafestival`.`reviews`.`r_id`      AS `r_id`,
       `chinafestival`.`reviews`.`d_dateime` AS `d_dateime`,
       `chinafestival`.`reviews`.`d_id`      AS `d_id`,
       `chinafestival`.`reviews`.`d_details` AS `d_details`,
       `chinafestival`.`reviews`.`u_id`      AS `u_id`
from (`chinafestival`.`users`
         join `chinafestival`.`reviews` on ((`chinafestival`.`users`.`u_id` = `chinafestival`.`reviews`.`u_id`)));

