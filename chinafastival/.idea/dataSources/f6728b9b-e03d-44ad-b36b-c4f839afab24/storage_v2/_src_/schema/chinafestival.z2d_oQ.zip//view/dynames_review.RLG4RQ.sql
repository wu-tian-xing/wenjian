create definer = root@localhost view dynames_review as
select `chinafestival`.`reviews`.`r_id`        AS `r_id`,
       `chinafestival`.`reviews`.`d_dateime`   AS `d_dateime`,
       `chinafestival`.`reviews`.`d_id`        AS `d_id`,
       `chinafestival`.`reviews`.`d_details`   AS `d_details`,
       `chinafestival`.`reviews`.`u_id`        AS `u_id`,
       `chinafestival`.`dynamics`.`details`    AS `details`,
       `chinafestival`.`dynamics`.`picture`    AS `picture`,
       `chinafestival`.`dynamics`.`datetime`   AS `datetime`,
       `chinafestival`.`dynamics`.`user_id`    AS `user_id`,
       `chinafestival`.`dynamics`.`num_review` AS `num_review`,
       `chinafestival`.`dynamics`.`praise`     AS `praise`
from `chinafestival`.`dynamics`
         join `chinafestival`.`reviews`;

