create definer = root@localhost view dynamics_view as
select `chinafestival`.`dynamics`.`d_id`     AS `d_id`,
       `chinafestival`.`dynamics`.`details`  AS `details`,
       `chinafestival`.`dynamics`.`picture`  AS `picture`,
       `chinafestival`.`dynamics`.`datetime` AS `datetime`,
       `chinafestival`.`dynamics`.`user_id`  AS `user_id`,
       `chinafestival`.`users`.`u_name`      AS `u_name`,
       `chinafestival`.`users`.`headphoto`   AS `headphoto`
from `chinafestival`.`users`
         join `chinafestival`.`dynamics`;

